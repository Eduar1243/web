<?php
$API_URL = "https://68507457e7c42cfd1798bdda.mockapi.io/api/v1/bicicletas";
$json   = @file_get_contents($API_URL);
$datos  = json_decode($json, true);
if ($datos === null) {
    $errorApi = "❌ No se pudo conectar con la API.";
}
$busqueda   = isset($_GET['q']) ? trim($_GET['q']) : '';
$productos = [];
if ($busqueda && is_array($datos)) {
    $buscMin = mb_strtolower($busqueda);
    foreach ($datos as $bici) {
        if (strpos(mb_strtolower($bici['nombre']), $buscMin) !== false) {
            $productos[] = $bici;
        }
    }
} elseif (is_array($datos) && $busqueda != '') {
    $productos = $datos;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>BiciAccesorios</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <script defer src="webmedia.js"></script>
</head>
<body>
  <header class="bg-primary text-white text-center py-4 mb-4">
    <h1>Bici Accesorios</h1>
    <section class="d-flex justify-content-center align-items-center">
      <img src="img/carrito de compras.png" alt="carrito" width="40" class="me-2">
      <h2 class="h5">Carrito</h2>
    </section>
    <nav class="mt-3">
      <ul class="nav justify-content-center">
        <li class="nav-item"><a href="#productos" class="nav-link text-white">Productos</a></li>
        <li class="nav-item"><a href="#contacto" class="nav-link text-white">Contacto</a></li>
      </ul>
    </nav>
  </header>

  <main class="container">
    <section id="bienvenida" class="text-center mb-4">
      <h3>Bienvenido a Bici Accesorios</h3>
      <p>Tu tienda de confianza para conseguir accesorios de calidad para todo tipo de bicicletas.</p>
    </section>

    <section id="productos">
      <h4 class="text-center">Nuestros Productos</h4>

      <form method="GET" class="d-flex justify-content-center my-3">
        <input type="text" name="q" class="form-control w-50 me-2" placeholder="Buscar bicicleta por categoría..." required>
        <button class="btn btn-primary" type="submit">Buscar</button>
      </form>

      <?php if (isset($errorApi)): ?>
        <p class="text-danger text-center fw-bold">
          <?= $errorApi ?>
        </p>
      <?php endif; ?>

      <?php if (!empty($productos)): ?>
        <div class="row">
        <?php foreach ($productos as $producto): ?>
          <div class="col-md-4 mb-4">
            <div class="card h-100">
              <img src="<?= $producto['imagen'] ?>" class="card-img-top" alt="<?= $producto['nombre'] ?>">
              <div class="card-body">
                <h5 class="card-title"><?= $producto['nombre'] ?></h5>
                <p class="card-text"><strong>Terreno:</strong> <?= htmlspecialchars($producto['tipo_terreno']) ?></p>
                <p class="card-text"><?= $producto['descripcion'] ?></p>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </section>

    <section id="producto" class="row">
      <!-- productos locales visibles siempre -->
      <div class="col-md-3 mb-4">
        <div class="card h-100">
          <img src="img/relacion.jpg" class="card-img-top" alt="Shimano Deore">
          <div class="card-body">
            <h5 class="card-title">Relación MTB 1x10</h5>
            <p class="card-text">$450.000</p>
            <p class="card-text">Relación Shimano Deore MTB 1x10.</p>
            <button class="btn btn-primary btn-comprar">
              <i class="bi bi-cart-plus"></i> Comprar
            </button>
            <button class="btn btn-outline-secondary btn-agregar">
              <i class="bi bi-plus-circle"></i> Agregar al carrito
            </button>
          </div>
        </div>
      </div>
      <div class="col-md-3 mb-4">
        <div class="card h-100">
          <img src="img/suspension.jpg" class="card-img-top" alt="Suspensión Fox 29">
          <div class="card-body">
            <h5 class="card-title">Suspensión Fox Racing Shox</h5>
            <p class="card-text">$4.300.000</p>
            <p class="card-text">Protege tus articulaciones y reduce los impactos causados por la vibración.</p>
            <button class="btn btn-primary btn-comprar">
              <i class="bi bi-cart-plus"></i> Comprar
            </button>
            <button class="btn btn-outline-secondary btn-agregar">
              <i class="bi bi-plus-circle"></i> Agregar al carrito
            </button>
          </div>
        </div>
      </div>
      <div class="col-md-3 mb-4">
        <div class="card h-100">
          <img src="img/llantas.jpg" class="card-img-top" alt="Llantas Maxxis ikon29">
          <div class="card-body">
            <h5 class="card-title">Maxxis Ikon 29</h5>
            <p class="card-text">$95.000</p>
            <p class="card-text">Desafía los terrenos más difíciles con nuestras llantas Maxxis.</p>
            <button class="btn btn-primary btn-comprar">
              <i class="bi bi-cart-plus"></i> Comprar
            </button>
            <button class="btn btn-outline-secondary btn-agregar">
              <i class="bi bi-plus-circle"></i> Agregar al carrito
            </button>
          </div>
        </div>
      </div>
      <div class="col-md-3 mb-4">
        <div class="card h-100">
          <img src="img/guantes.jpg" class="card-img-top" alt="GUANTES FOX">
          <div class="card-body">
            <h5 class="card-title">GUANTES FOX FLEXAIR PARK</h5>
            <p class="card-text">$84.900</p>
            <p class="card-text">La mejor protección para tus manos.</p>
            <button class="btn btn-primary btn-comprar">
              <i class="bi bi-cart-plus"></i> Comprar
            </button>
            <button class="btn btn-outline-secondary btn-agregar">
              <i class="bi bi-plus-circle"></i> Agregar al carrito
            </button>
          </div>
        </div>
      </div>
    </section>

    <!-- VIDEO INFORMATIVO -->
<section class="my-5">
  <h3 class="text-center mb-3">¿Por qué elegir Bici Accesorios?</h3>
  <div class="ratio ratio-16x9">
    <iframe src="https://www.youtube.com/embed/XUD2l2UYELI"
            title="Video de Bici Accesorios"
            allowfullscreen
            loading="lazy"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            style="border-radius: 12px;"></iframe>
  </div>
</section>


    <section id="contacto" class="mb-5">
      <h3>Contáctanos</h3>
      
      <!-- 
        FORMULARIO DE CONTACTO
        - id="contactForm": Usado por JavaScript para identificar el formulario.
        - action y method: Aunque usamos AJAX, es una buena práctica mantenerlos como respaldo.
        - La clase "row g-3" es de Bootstrap para el layout de los campos.
      -->
      <form action="guardar.php" method="POST" id="contactForm" class="row g-3">
        
        <!-- Campo oculto para guardar el ID del mensaje cuando se está editando -->
        <input type="hidden" id="id" name="id">

        <div class="col-md-6">
          <label for="nombre" class="form-label">Nombre:</label>
          <input type="text" id="nombre" name="nombre" class="form-control" required>
        </div>
        <div class="col-md-6">
          <label for="correo_electronico" class="form-label">Correo electrónico:</label>
          <input type="email" id="correo_electronico" name="correo_electronico" class="form-control" required>
        </div>
        <div class="col-12">
          <label for="mensaje" class="form-label">Mensaje:</label>
          <textarea id="mensaje" name="mensaje" rows="4" class="form-control" required></textarea>
        </div>
        <div class="col-12">
          <!-- 
            BOTONES DE ACCIÓN DEL FORMULARIO
            - Enviar (submit): Crea un nuevo registro.
            - Modificar (submit): Actualiza un registro existente. Su visibilidad es controlada por JS.
            - Limpiar (button): Llama a la función JS limpiarFormulario().
            - Cerrar (button): Llama a la función JS cerrarFormulario().
            - El botón Eliminar se ha quitado de aquí, ya que la acción se realiza en la tabla.
          -->
          <button type="submit" name="accion" value="Enviar" class="btn btn-success me-2">
            <i class="bi bi-send"></i> Enviar
          </button>
          <button type="submit" name="accion" value="Modificar" class="btn btn-warning me-2" style="display: none;">
            <i class="bi bi-pencil"></i> Modificar
          </button>
          <button type="button" onclick="limpiarFormulario()" class="btn btn-secondary me-2">
            <i class="bi bi-eraser"></i> Limpiar
          </button>
          <button type="button" onclick="cerrarFormulario()" class="btn btn-dark">
            <i class="bi bi-x-circle"></i> Cerrar
          </button>
        </div>
      </form>

      <div class="mt-4">
        <h4>Mensajes Enviados</h4>
        <!--
          TABLA DE MENSAJES
          - Esta tabla muestra los mensajes guardados en la base de datos.
          - El contenido del <tbody> (cuerpo de la tabla) con id="tablaMensajes"
            es cargado dinámicamente por JavaScript (ver webmedia.js).
        -->
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>Nombre</th>
              <th>Correo</th>
              <th>Mensaje</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody id="tablaMensajes">
            <!-- Los mensajes cargados desde la base de datos aparecerán aquí -->
          </tbody>
        </table>
      </div>
    </section>

    <section id="carrito" class="border p-3 mb-5">
      <h3><i class="bi bi-cart3"></i> Carrito de compras</h3>
      <div id="carrito-vacio" class="text-center text-muted py-4">
        <i class="bi bi-cart-x" style="font-size: 3rem;"></i>
        <p class="mt-2">Tu carrito está vacío</p>
      </div>
      <ul id="lista-carrito" class="list-group mb-3"></ul>
      <div class="d-flex justify-content-between align-items-center">
        <h5><strong>Total: </strong>$<span id="total">0</span></h5>
        <button id="pagar" class="btn btn-primary">
          <i class="bi bi-credit-card"></i> Pagar
        </button>
      </div>
    </section>
  </main>

  <footer class="bg-light text-center py-3">
    <p class="mb-0">&copy; 2025 BiciAccesorios. Todos los derechos reservados.</p>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>