// Lógica completa para carrito y formulario
document.addEventListener("DOMContentLoaded", () => {
  console.log("JavaScript cargado correctamente");
  
  const carrito = [];
  const listaCarrito = document.getElementById("lista-carrito");
  const totalSpan = document.getElementById("total");

  // ===== FUNCIONALIDAD DEL CARRITO =====
  
  function actualizarCarrito() {
    console.log("Actualizando carrito...");
    listaCarrito.innerHTML = "";
    let total = 0;
    const carritoVacio = document.getElementById("carrito-vacio");

    if (carrito.length === 0) {
      carritoVacio.style.display = 'block';
      totalSpan.textContent = '0';
      return;
    } else {
      carritoVacio.style.display = 'none';
    }

    carrito.forEach((item, index) => {
      const li = document.createElement("li");
      li.classList.add("list-group-item", "d-flex", "justify-content-between", "align-items-center");
      
      li.innerHTML = `
        <div>
          <strong>${item.nombre}</strong> - $${item.precio.toLocaleString()}
          <span class="badge bg-secondary ms-2">Cantidad: ${item.cantidad}</span>
        </div>
        <div>
          <button class="btn btn-sm btn-outline-danger me-1" onclick="eliminarDelCarrito(${index})">
            <i class="bi bi-trash"></i> Eliminar
          </button>
        </div>
      `;
      
      listaCarrito.appendChild(li);
      total += item.precio * item.cantidad;
    });

    totalSpan.textContent = total.toLocaleString();
    console.log("Carrito actualizado:", carrito);
  }

  function agregarAlCarrito(nombre, precio) {
    console.log("Agregando al carrito:", nombre, precio);
    
    // Buscar si el producto ya está en el carrito
    const productoExistente = carrito.find(item => item.nombre === nombre);
    
    if (productoExistente) {
      productoExistente.cantidad += 1;
    } else {
      carrito.push({ 
        nombre, 
        precio: parseInt(precio), 
        cantidad: 1 
      });
    }
    
    actualizarCarrito();
    mostrarNotificacion(`✅ Producto agregado: ${nombre}`, 'success');
  }

  // Función global para eliminar del carrito
  window.eliminarDelCarrito = function(index) {
    console.log("Eliminando del carrito índice:", index);
    carrito.splice(index, 1);
    actualizarCarrito();
    mostrarNotificacion('Producto eliminado del carrito', 'info');
  };

  // Conectar botones de productos locales
  function conectarBotonesProductos() {
    console.log("Conectando botones de productos...");
    
    // Botones agregar al carrito
    const botonesAgregar = document.querySelectorAll(".btn-agregar");
    console.log("Botones agregar encontrados:", botonesAgregar.length);
    
    botonesAgregar.forEach((btn, index) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        console.log("Botón agregar clickeado:", index);
        const card = btn.closest('.card');
        const nombre = card.querySelector('.card-title').textContent;
        const precioTexto = card.querySelector('.card-text').textContent;
        const precio = precioTexto.replace(/[^\d]/g, ''); // Extraer solo números
        console.log("Datos extraídos:", nombre, precio);
        agregarAlCarrito(nombre, precio);
      });
    });

    // Botones comprar
    const botonesComprar = document.querySelectorAll(".btn-comprar");
    console.log("Botones comprar encontrados:", botonesComprar.length);
    
    botonesComprar.forEach((btn, index) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        console.log("Botón comprar clickeado:", index);
        const card = btn.closest('.card');
        const nombre = card.querySelector('.card-title').textContent;
        const precioTexto = card.querySelector('.card-text').textContent;
        const precio = precioTexto.replace(/[^\d]/g, ''); // Extraer solo números
        console.log("Datos extraídos:", nombre, precio);
        agregarAlCarrito(nombre, precio);
        mostrarNotificacion(`🛒 Compra simulada: ${nombre}`, 'success');
      });
    });
  }

  // Botón pagar
  const botonPagar = document.getElementById("pagar");
  if (botonPagar) {
    botonPagar.addEventListener("click", () => {
      console.log("Botón pagar clickeado");
      if (carrito.length === 0) {
        mostrarNotificacion('El carrito está vacío', 'warning');
        return;
      }
      
      const total = carrito.reduce((sum, item) => sum + (item.precio * item.cantidad), 0);
      mostrarNotificacion(`💳 Pago simulado por $${total.toLocaleString()}`, 'success');
      
      // Limpiar carrito después del pago
      carrito.length = 0;
      actualizarCarrito();
    });
  }

  // ===== FUNCIONALIDAD DEL FORMULARIO =====
  
  const formulario = document.getElementById("contactForm");
  const tablaMensajes = document.getElementById("tablaMensajes");
  let modoEdicion = false;
  let idEditando = null;

  // Cargar mensajes al iniciar
  cargarMensajes();

  // Manejar envío del formulario
  if (formulario) {
    formulario.addEventListener("submit", async (e) => {
      e.preventDefault();
      console.log("Formulario enviado");
      
      const formData = new FormData(formulario);
      const accion = formData.get('accion');
      console.log("Acción:", accion);
      
      try {
        const response = await fetch('guardar.php', {
          method: 'POST',
          body: formData
        });
        
        const resultado = await response.json();
        console.log("Respuesta del servidor:", resultado);
        
        if (resultado.status === 'success') {
          mostrarNotificacion(resultado.message, 'success');
          limpiarFormulario();
          cargarMensajes();
        } else {
          mostrarNotificacion(resultado.message, 'error');
        }
      } catch (error) {
        console.error("Error en formulario:", error);
        mostrarNotificacion('Error de conexión', 'error');
      }
    });
  }

  // Función para cargar mensajes
  async function cargarMensajes() {
    console.log("Cargando mensajes...");
    try {
      const response = await fetch('cargar_mensajes.php');
      const html = await response.text();
      console.log("HTML recibido:", html);
      tablaMensajes.innerHTML = html;
      
      // Agregar event listeners a los botones de editar y eliminar
      agregarEventListenersTabla();
    } catch (error) {
      console.error('Error al cargar mensajes:', error);
    }
  }

  // Función para agregar event listeners a la tabla
  function agregarEventListenersTabla() {
    console.log("Agregando event listeners a la tabla...");
    
    // Botones editar
    const botonesEditar = document.querySelectorAll('.btn-editar');
    console.log("Botones editar encontrados:", botonesEditar.length);
    
    botonesEditar.forEach(btn => {
      btn.addEventListener("click", () => {
        console.log("Botón editar clickeado");
        const id = btn.getAttribute('data-id');
        const nombre = btn.getAttribute('data-nombre');
        const correo = btn.getAttribute('data-correo');
        const mensaje = btn.getAttribute('data-mensaje');
        
        editarMensaje(id, nombre, correo, mensaje);
      });
    });

    // Botones eliminar
    const botonesEliminar = document.querySelectorAll('.btn-eliminar');
    console.log("Botones eliminar encontrados:", botonesEliminar.length);
    
    botonesEliminar.forEach(btn => {
      btn.addEventListener("click", () => {
        console.log("Botón eliminar clickeado");
        const id = btn.getAttribute('data-id');
        eliminarMensaje(id);
      });
    });
  }

  // Función para editar mensaje
  function editarMensaje(id, nombre, correo, mensaje) {
    console.log("Editando mensaje:", id, nombre);
    document.getElementById('id').value = id;
    document.getElementById('nombre').value = nombre;
    document.getElementById('correo_electronico').value = correo;
    document.getElementById('mensaje').value = mensaje;
    
    modoEdicion = true;
    idEditando = id;
    
    // Cambiar visibilidad de botones
    const botonEnviar = document.querySelector('button[value="Enviar"]');
    const botonModificar = document.querySelector('button[value="Modificar"]');
    
    if (botonEnviar) botonEnviar.style.display = 'none';
    if (botonModificar) botonModificar.style.display = 'inline-block';
    
    mostrarNotificacion('Modo edición activado', 'info');
  }

  // Función para eliminar mensaje
  async function eliminarMensaje(id) {
    console.log("Eliminando mensaje:", id);
    if (!confirm('¿Estás seguro de que quieres eliminar este mensaje?')) {
      return;
    }
    
    const formData = new FormData();
    formData.append('accion', 'Eliminar');
    formData.append('id', id);
    
    try {
      const response = await fetch('guardar.php', {
        method: 'POST',
        body: formData
      });
      
      const resultado = await response.json();
      console.log("Respuesta eliminar:", resultado);
      
      if (resultado.status === 'success') {
        mostrarNotificacion(resultado.message, 'success');
        cargarMensajes();
      } else {
        mostrarNotificacion(resultado.message, 'error');
      }
    } catch (error) {
      console.error("Error al eliminar:", error);
      mostrarNotificacion('Error al eliminar', 'error');
    }
  }

  // ===== FUNCIONES GLOBALES =====
  
  // Función para limpiar formulario
  window.limpiarFormulario = function() {
    console.log("Limpiando formulario");
    formulario.reset();
    document.getElementById('id').value = '';
    modoEdicion = false;
    idEditando = null;
    
    // Restaurar visibilidad de botones
    const botonEnviar = document.querySelector('button[value="Enviar"]');
    const botonModificar = document.querySelector('button[value="Modificar"]');
    
    if (botonEnviar) botonEnviar.style.display = 'inline-block';
    if (botonModificar) botonModificar.style.display = 'none';
    
    mostrarNotificacion('Formulario limpiado', 'info');
  };

  // Función para cerrar formulario
  window.cerrarFormulario = function() {
    console.log("Cerrando formulario");
    if (modoEdicion) {
      if (confirm('¿Estás seguro de que quieres cerrar? Se perderán los cambios.')) {
        limpiarFormulario();
      }
    } else {
      limpiarFormulario();
    }
  };

  // Función para mostrar notificaciones
  function mostrarNotificacion(mensaje, tipo) {
    console.log("Mostrando notificación:", mensaje, tipo);
    // Crear elemento de notificación
    const notificacion = document.createElement('div');
    notificacion.className = `alert alert-${tipo === 'error' ? 'danger' : tipo} alert-dismissible fade show position-fixed`;
    notificacion.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    
    notificacion.innerHTML = `
      ${mensaje}
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notificacion);
    
    // Remover automáticamente después de 3 segundos
    setTimeout(() => {
      if (notificacion.parentNode) {
        notificacion.remove();
      }
    }, 3000);
  }

  // Inicializar todo
  console.log("Inicializando aplicación...");
  conectarBotonesProductos();
  actualizarCarrito();
  console.log("Aplicación inicializada correctamente");
});
